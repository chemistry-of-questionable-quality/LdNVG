LAFVIN ESP32-S3 / OV3660 Night Vision - Fast Test Build

Files:
- lafvin_nightvision_fast.ino

This build is based on the uploaded exposure_2 sketch.

Changes:
- Starts at B1 (setting index 17) rather than automatic night level 5.
- Reduces EXP_MED from 350 to 280 and EXP_LONG from 1200 to 560.
- Uses 16 KB DMA blocks and raises the LCD task priority slightly.
- Enables the OV3660 60 Hz banding filter setting.
- Smooths the software row-correction estimate across frames to reduce
  correction shimmer.

Important:
- The camera/display combination has not been physically tested here.
- This is an experimental test build, not a verified compile.
- The 60 Hz sensor setting is appropriate for North American mains-powered
  lighting. If the IR illuminator itself is PWM-driven, it can still create
  bands; try a constant-current/DC IR illuminator or its non-PWM mode.
- To compare performance fairly, test B1, B2, then B3 in the same lighting.
- If B1 is too dark, try B2. If B3 slows down, reduce EXP_LONG further.
- If the display glitches, lower SPI_HZ from 80000000 to 40000000.
- Board settings: ESP32S3 Dev Module, PSRAM = OPI PSRAM.
