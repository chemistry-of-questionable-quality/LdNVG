LAFVIN ESP32-S3 OV3660 timing diagnostic
==========================================

This is your ORIGINAL exposure_2 sketch with timing measurements added.
It intentionally preserves the original camera, exposure, image-processing,
DMA, SPI, and display settings. It is diagnostic, not a speed-tuned build.

Upload:
- Arduino IDE board: ESP32S3 Dev Module
- PSRAM: OPI PSRAM
- Open Serial Monitor at 115200 baud.

Use the same lighting and target as your normal test. Let it run for 5-10
seconds, preferably in grayscale with edge highlighting off. The LCD overlay
continues to show the display FPS. Serial output now adds:
- capture: time spent waiting for esp_camera_fb_get()
- process: time spent converting/processing/drawing the frame
- LCD: time spent sending a frame to the display

Please send 5-10 consecutive lines from Serial Monitor and tell me which
setting (for example Night 5, F1, B1) was active. These measurements will
show which stage is limiting the frame rate so the next optimization can
target that stage without changing image quality.

No actual compile or hardware test was possible here; this is based on your
working original sketch and only adds micros() measurements and Serial text.
