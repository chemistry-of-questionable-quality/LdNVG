// Near-IR night vision monocular -- LAFVIN ESP32-S3 1.69" LCD board (OV3660)
// NO EXTRA LIBRARIES: uses only SPI.h and esp_camera.h from the ESP32 core,
// with a small built-in ST7789 driver.
//
// 20 settings in GRAYSCALE and 20 in COLOUR:
//   L1-L4 = low-gain settings for bright / supplemental IR (L1 dimmest)
//   1-10  = night gain levels (10 = the old BOOST setting)
//   F1-F3 = capped exposure, modest gain: higher frame rate
//   B1-B3 = capped exposure, boosted gain: higher frame rate, brighter, grainier
// After the last setting the cycle repeats all of them with EDGE HIGHLIGHTING,
// then goes back to plain again.
//
// BOOT button (GPIO0):
//   short press (under 0.8 s) = next step: L1..L4, 1..10, F1..F3, B1..B3, then the same with edges, ...
//   medium hold (0.8 - 2 s)   = cycle LCD backlight (100% -> 50% -> 15% -> 4%)
//   long hold   (over 2 s)    = switch GRAYSCALE <-> COLOUR
//
// Status overlay (drawn on the image, top-left; backlight bars top-right):
//   square          = palette (grey = grayscale, orange = colour)
//   first number    = setting L1-L4 or 1-10 (cyan), "E" after it = edge highlighting on
//   second number   = frames per second (green)
//   4 bars (right)  = backlight level
//
// Board settings: ESP32S3 Dev Module, PSRAM = OPI PSRAM.
// Start-up error colours: RED screen = no PSRAM, MAGENTA = camera init failed.
//
// Speed-ups (set to 0 to turn off if anything misbehaves):
//   USE_PIPELINE : camera capture + processing run on one CPU core while the other
//                  core sends the previous frame to the screen
//   USE_DMA_SPI  : screen transfer uses DMA (falls back to the plain SPI library
//                  automatically if DMA is unavailable or fails to start)

#define USE_PIPELINE 1
#define USE_DMA_SPI  1

// 1 = capture YUV422 and convert to RGB565 on the ESP32, with edge detection working
// on true 8-bit brightness (looked better in testing). 0 = camera outputs RGB565.
#define CAPTURE_YUV  1
// If CAPTURE_YUV is 1 and the picture looks wrong (grainy/striped or odd colours),
// try 1 here: it switches the expected byte order from YUYV to UYVY.
#define YUV_ORDER_UYVY 0

#include <SPI.h>
#include "esp_camera.h"

#if USE_DMA_SPI && defined(__has_include)
#if __has_include(<driver/spi_master.h>)
#include <driver/spi_master.h>
#include <esp_heap_caps.h>
#define LCD_DMA 1
#endif
#endif
#ifndef LCD_DMA
#define LCD_DMA 0
#endif

// ---------- LCD pins ----------
#define TFT_MOSI 39
#define TFT_SCLK 38
#define TFT_CS   14
#define TFT_DC   10
#define TFT_RST  3
#define TFT_BL   13
#define BTN_PIN  0

#define SPI_HZ   80000000   // lower to 40000000 if the picture glitches
#define ROW_OFF  20         // 240x280 panel sits 20 rows into the controller RAM
#define SCR_W    240
#define SCR_H    280
#define STRIP_H  20         // work-buffer height used when clearing the screen
// Camera resolution. 240x240 fills the screen width. Smaller sizes (for example
// FRAMESIZE_HQVGA = 240x176, FRAMESIZE_QQVGA = 160x120) leave black borders; the
// picture is always centred on the screen.
#define CAM_FRAMESIZE FRAMESIZE_240X240
#define SWAP_BYTES 0        // set to 1 if red and blue look swapped

// ---------- Camera pins (OV3660) ----------
#define PWDN_GPIO_NUM   -1
#define RESET_GPIO_NUM  -1
#define XCLK_GPIO_NUM   17
#define SIOD_GPIO_NUM   1
#define SIOC_GPIO_NUM   2
#define VSYNC_GPIO_NUM  21
#define HREF_GPIO_NUM   18
#define PCLK_GPIO_NUM   16
#define Y2_GPIO_NUM     7
#define Y3_GPIO_NUM     5
#define Y4_GPIO_NUM     4
#define Y5_GPIO_NUM     6
#define Y6_GPIO_NUM     8
#define Y7_GPIO_NUM     9
#define Y8_GPIO_NUM     11
#define Y9_GPIO_NUM     15

// Flip these if the image is upside down / mirrored in your housing
#define IMG_VFLIP    1
#define IMG_HMIRROR  0

// Status LED (WS2812) on the board: GPIO 48 per Lafvin's pin_config.h.
// Set to -1 to leave the LED alone.
#define LED_GPIO 48

// Edge highlighting. Each setting has its own sensitivity in the table below.
// EDGE_SCALE adjusts them all at once, in percent: below 100 = more edges (and more
// noise), above 100 = fewer edges.
#define EDGE_SCALE     100
#define EDGE_THICK     0        // 0 = 1-pixel highlights, 1 = 2 pixels thick
#define EDGE_COLOR     0xFFE0   // RGB565 yellow

// =====================================================================
//  Minimal ST7789 driver
// =====================================================================
SPIClass lcdSPI(HSPI);
static const SPISettings lcdSettings(SPI_HZ, MSBFIRST, SPI_MODE0);
static uint8_t stripBuf[SCR_W * STRIP_H * 2];   // 9600 bytes, used for clearing the screen

// ---------- low-level SPI backend: DMA if available, otherwise the SPI library ----------
#if LCD_DMA
#define DMA_CHUNK 8192                 // bytes per DMA transfer (even number)
static spi_device_handle_t lcdDev = NULL;
static uint8_t *dmaBuf[2] = {NULL, NULL};
static spi_transaction_t dmaTrans[2];
static bool useDma = false;

static bool dmaInit() {
  spi_bus_config_t bus = {};
  bus.mosi_io_num = TFT_MOSI;
  bus.miso_io_num = -1;
  bus.sclk_io_num = TFT_SCLK;
  bus.quadwp_io_num = -1;
  bus.quadhd_io_num = -1;
  bus.max_transfer_sz = DMA_CHUNK;
  if (spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO) != ESP_OK) return false;

  const uint32_t speeds[2] = {SPI_HZ, 40000000};   // try the full speed, then 40 MHz
  for (int i = 0; i < 2 && !lcdDev; i++) {
    spi_device_interface_config_t dev = {};
    dev.clock_speed_hz = speeds[i];
    dev.mode = 0;
    dev.spics_io_num = -1;             // chip-select is driven by hand
    dev.queue_size = 2;
    if (spi_bus_add_device(SPI2_HOST, &dev, &lcdDev) != ESP_OK) lcdDev = NULL;
  }
  if (!lcdDev) { spi_bus_free(SPI2_HOST); return false; }

  for (int i = 0; i < 2; i++)
    dmaBuf[i] = (uint8_t *)heap_caps_malloc(DMA_CHUNK, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
  if (!dmaBuf[0] || !dmaBuf[1]) {
    for (int i = 0; i < 2; i++) { if (dmaBuf[i]) heap_caps_free(dmaBuf[i]); dmaBuf[i] = NULL; }
    spi_bus_remove_device(lcdDev);
    lcdDev = NULL;
    spi_bus_free(SPI2_HOST);
    return false;
  }
  return true;
}
#endif

static void spiInit() {
#if LCD_DMA
  useDma = dmaInit();
  if (useDma) return;
#endif
  lcdSPI.begin(TFT_SCLK, -1, TFT_MOSI, -1);
}

// Sends n bytes. With DMA: copies 8 KB pieces into internal memory and queues them,
// so the copy of one piece overlaps the DMA transfer of the previous one.
static void spiWrite(const uint8_t *d, size_t n) {
#if LCD_DMA
  if (useDma) {
    int inflight = 0, idx = 0;
    size_t off = 0;
    while (off < n) {
      size_t len = n - off;
      if (len > DMA_CHUNK) len = DMA_CHUNK;
      if (inflight == 2) {                               // both buffers busy: wait for the older one
        spi_transaction_t *done;
        spi_device_get_trans_result(lcdDev, &done, portMAX_DELAY);
        inflight--;
      }
      memcpy(dmaBuf[idx], d + off, len);
      memset(&dmaTrans[idx], 0, sizeof(spi_transaction_t));
      dmaTrans[idx].length = len * 8;                    // length is in bits
      dmaTrans[idx].tx_buffer = dmaBuf[idx];
      spi_device_queue_trans(lcdDev, &dmaTrans[idx], portMAX_DELAY);
      inflight++;
      idx ^= 1;
      off += len;
    }
    while (inflight > 0) {
      spi_transaction_t *done;
      spi_device_get_trans_result(lcdDev, &done, portMAX_DELAY);
      inflight--;
    }
    return;
  }
#endif
  lcdSPI.beginTransaction(lcdSettings);
  lcdSPI.writeBytes(d, n);
  lcdSPI.endTransaction();
}

void lcdCmd(uint8_t c) {
  digitalWrite(TFT_DC, LOW);
  digitalWrite(TFT_CS, LOW);
  spiWrite(&c, 1);
  digitalWrite(TFT_CS, HIGH);
}

void lcdData(const uint8_t *d, size_t n) {
  digitalWrite(TFT_DC, HIGH);
  digitalWrite(TFT_CS, LOW);
  spiWrite(d, n);
  digitalWrite(TFT_CS, HIGH);
}

void lcdCmdData(uint8_t c, const uint8_t *d, size_t n) {
  lcdCmd(c);
  if (n) lcdData(d, n);
}

#define CMD(c, ...) do { const uint8_t d_[] = {__VA_ARGS__}; lcdCmdData(c, d_, sizeof(d_)); } while (0)

void lcdSetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
  y0 += ROW_OFF;
  y1 += ROW_OFF;
  CMD(0x2A, (uint8_t)(x0 >> 8), (uint8_t)x0, (uint8_t)(x1 >> 8), (uint8_t)x1);
  CMD(0x2B, (uint8_t)(y0 >> 8), (uint8_t)y0, (uint8_t)(y1 >> 8), (uint8_t)y1);
  lcdCmd(0x2C);   // memory write
}

// data = big-endian RGB565 (high byte first)
void lcdPush(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t *data) {
  lcdSetWindow(x, y, x + w - 1, y + h - 1);
  lcdData(data, (size_t)w * h * 2);
}

void lcdInit() {
  pinMode(TFT_DC, OUTPUT);
  pinMode(TFT_CS, OUTPUT);
  pinMode(TFT_RST, OUTPUT);
  digitalWrite(TFT_CS, HIGH);
  spiInit();

  digitalWrite(TFT_RST, HIGH); delay(10);
  digitalWrite(TFT_RST, LOW);  delay(20);
  digitalWrite(TFT_RST, HIGH); delay(120);

  lcdCmd(0x01); delay(150);          // software reset
  lcdCmd(0x11); delay(120);          // sleep out
  CMD(0x3A, 0x55);                   // 16-bit colour
  CMD(0x36, 0x00);                   // orientation / RGB order
  CMD(0xB2, 0x0C, 0x0C, 0x00, 0x33, 0x33);
  CMD(0xB7, 0x35);
  CMD(0xBB, 0x19);
  CMD(0xC0, 0x2C);
  CMD(0xC2, 0x01);
  CMD(0xC3, 0x12);
  CMD(0xC4, 0x20);
  CMD(0xC6, 0x0F);
  CMD(0xD0, 0xA4, 0xA1);
  CMD(0xE0, 0xD0, 0x04, 0x0D, 0x11, 0x13, 0x2B, 0x3F, 0x54, 0x4C, 0x18, 0x0D, 0x0B, 0x1F, 0x23);
  CMD(0xE1, 0xD0, 0x04, 0x0C, 0x11, 0x13, 0x2C, 0x3F, 0x44, 0x51, 0x2F, 0x1F, 0x1F, 0x20, 0x23);
  lcdCmd(0x21);                      // display inversion on (needed for this IPS panel)
  lcdCmd(0x13);                      // normal mode
  lcdCmd(0x29);                      // display on
  delay(20);
}

// Fill the whole screen with one RGB565 colour
void lcdFill(uint16_t color) {
  for (size_t i = 0; i < sizeof(stripBuf); i += 2) {
    stripBuf[i] = color >> 8;
    stripBuf[i + 1] = color & 0xFF;
  }
  for (int y = 0; y < SCR_H; y += STRIP_H) lcdPush(0, y, SCR_W, STRIP_H, stripBuf);
}

// =====================================================================
//  On-image overlay helpers (draw straight into the camera frame, big-endian RGB565)
// =====================================================================
// 3x5 digit font, 15 bits each (row-major, MSB = top-left)
static const uint16_t DIGITS[14] = {0x7B6F, 0x2C97, 0x73E7, 0x73CF, 0x5BC9,
                                    0x79CF, 0x79EF, 0x7249, 0x7BEF, 0x7BCF,
                                    0x79E7 /* 10 = E */, 0x4927 /* 11 = L */,
                                    0x79E4 /* 12 = F */, 0x6BAE /* 13 = B */};
static uint16_t *ovBuf;
static int ovW, ovH;

static void ovPix(int x, int y, uint16_t c) {
  if (x < 0 || x >= ovW || y < 0 || y >= ovH) return;
  ovBuf[(size_t)y * ovW + x] = __builtin_bswap16(c);
}
static void ovRect(int x, int y, int w, int h, uint16_t c) {
  for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) ovPix(x + xx, y + yy, c);
}
// Glyph drawn at 2x size with a black drop-shadow so it stays readable on any picture
static void ovGlyph(int x, int y, int idx, uint16_t c) {
  uint16_t g = DIGITS[idx];
  for (int pass = 0; pass < 2; pass++)
    for (int r = 0; r < 5; r++)
      for (int col = 0; col < 3; col++)
        if (g & (1 << (14 - (r * 3 + col))))
          ovRect(x + col * 2 + (pass == 0), y + r * 2 + (pass == 0), 2, 2, pass == 0 ? 0x0000 : c);
}

// =====================================================================
//  Backlight PWM (works on Arduino-ESP32 core 2.x and 3.x)
// =====================================================================
static const uint8_t BL_LEVELS[] = {255, 128, 38, 10};
static uint8_t blIndex = 0;

void backlightInit() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(TFT_BL, 5000, 8);
#else
  ledcSetup(0, 5000, 8);
  ledcAttachPin(TFT_BL, 0);
#endif
}
void backlightSet(uint8_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(TFT_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}

// =====================================================================
//  Gain levels (10 grayscale + 10 colour)
// =====================================================================
#define NUM_LEVELS 20
#define NUM_LOW    4     // entries 0-3   = L1..L4 (low gain for bright / supplemental IR)
#define NUM_NIGHT  10    // entries 4-13  = night levels 1..10
                         // entries 14-16 = F1..F3 (capped exposure, modest gain)
                         // entries 17-19 = B1..B3 (capped exposure, boosted gain)

// Capped-exposure values for F1-F3 and B1-B3. The camera is told to use exactly this
// exposure, so the frame rate stays high. Bigger number = longer exposure = brighter
// but slower. The units are sensor lines; the camera driver limits the value to one
// frame. If F3/B3 show a lower fps than F2/B2, lower EXP_LONG.
#define EXP_SHORT  150
#define EXP_MED    350
#define EXP_LONG   1200

// One row per setting.
//   gain   : manual camera gain (0-30)
//   ae     : auto-exposure target (-2 darker .. +2 brighter), used when exp = 0
//   bright : brightness (-2..2)
//   aec2   : 1 = sensor night-mode exposure (can slow the frame rate), 0 = off
//   exp    : 0 = automatic exposure, otherwise a fixed (capped) exposure
//   edge   : edge-detection threshold on a 0-255 brightness scale (lower = more sensitive)
//   clean  : 1 = noise clean-up for high-gain settings: removes horizontal banding
//            from the picture and uses smoother edge detection (YUV mode only for banding)
struct LevelDef { int8_t gain, ae, bright, aec2; int16_t exp; int16_t edge; int8_t clean; };
static const LevelDef LEVELS[NUM_LEVELS] = {
  {  0,  0,  0, 0, 0, 12, 0 },   // L1  (brightest IR scenes)
  {  1,  1,  0, 0, 0, 14, 0 },   // L2
  {  2,  1,  1, 0, 0, 18, 0 },   // L3
  {  4,  2,  1, 0, 0, 22, 0 },   // L4
  {  6,  2,  2, 1, 0, 32, 0 },   // 1
  {  9,  2,  2, 1, 0, 32, 0 },   // 2
  { 11,  2,  2, 1, 0, 32, 0 },   // 3
  { 13,  2,  2, 1, 0, 32, 0 },   // 4
  { 15,  2,  2, 1, 0, 32, 0 },   // 5
  { 18,  2,  2, 1, 0, 32, 0 },   // 6
  { 21,  2,  2, 1, 0, 32, 0 },   // 7
  { 24,  2,  2, 1, 0, 32, 0 },   // 8
  { 27,  2,  2, 1, 0, 32, 0 },   // 9
  { 30,  2,  2, 1, 0, 32, 0 },   // 10 = old BOOST
  {  8,  0,  2, 0, EXP_SHORT, 32, 0 },   // F1  fast, modest gain
  {  8,  0,  2, 0, EXP_MED,   32, 0 },   // F2
  {  8,  0,  2, 0, EXP_LONG,  32, 0 },   // F3
  { 30,  0,  2, 0, EXP_SHORT, 46, 1 },   // B1  fast, boosted gain (noisy: less sensitive edges + clean-up)
  { 30,  0,  2, 0, EXP_MED,   42, 1 },   // B2
  { 30,  0,  2, 0, EXP_LONG,  38, 1 },   // B3
};

static int  gainLevel  = 8;      // 0-based index into LEVELS, so this is night level 5
static bool colourMode = false;  // false = grayscale, true = colour
static bool edgesOn    = false;  // edge highlighting
static camera_config_t camCfg;   // kept so the camera can be restarted
static volatile float lastFps = 0;   // written by the display side, read by the overlay
// Diagnostic timing only: these values do not alter camera or image settings.
static volatile uint32_t lastCaptureUs = 0;
static volatile uint32_t lastProcessUs = 0;
static volatile uint32_t lastLcdUs = 0;

// Call a sensor function only if this sensor driver implements it.
#define SET(fn, ...) do { if (s->fn) s->fn(s, __VA_ARGS__); } while (0)

void applyLevel() {
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return;

  SET(set_vflip, IMG_VFLIP);
  SET(set_hmirror, IMG_HMIRROR);
  SET(set_lenc, 1);

  if (colourMode) {
    SET(set_special_effect, 0);    // normal colour
    SET(set_whitebal, 1);
    SET(set_awb_gain, 1);
    SET(set_saturation, 0);
  } else {
    SET(set_special_effect, 2);    // grayscale
    SET(set_whitebal, 0);
    SET(set_awb_gain, 0);
    SET(set_saturation, -2);
  }

  const LevelDef &d = LEVELS[gainLevel];
  SET(set_gain_ctrl, 0);                       // manual gain...
  SET(set_agc_gain, d.gain);                   // ...stepped by level
  if (d.exp > 0) {
    SET(set_exposure_ctrl, 0);                 // fixed exposure: keeps the frame rate up
    SET(set_aec_value, d.exp);
  } else {
    SET(set_exposure_ctrl, 1);                 // exposure stays automatic
  }
  SET(set_aec2, d.aec2);
  SET(set_ae_level, d.ae);
  SET(set_gainceiling, GAINCEILING_128X);
  SET(set_brightness, d.bright);
  SET(set_contrast, 1);
}

// ---------- two-core pipeline: core 1 captures/processes, core 0 sends to the screen ----------
#if USE_PIPELINE
static QueueHandle_t qFrames = NULL;     // holds at most one frame waiting for the screen
static int inFlight = 0;                 // frames queued or currently being sent

static void displayTask(void *arg) {
  (void)arg;
  uint32_t frames = 0, t0 = millis();
  for (;;) {
    camera_fb_t *fb = NULL;
    if (xQueueReceive(qFrames, &fb, portMAX_DELAY) != pdTRUE || !fb) continue;
    uint16_t x0 = (SCR_W - fb->width) / 2;
    uint16_t y0 = (SCR_H - fb->height) / 2;          // centred vertically
    uint32_t lcdStartUs = micros();
    lcdPush(x0, y0, fb->width, fb->height, fb->buf);
    lastLcdUs = micros() - lcdStartUs;
    esp_camera_fb_return(fb);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);

    frames++;
    if (millis() - t0 >= 1000) {
      lastFps = frames * 1000.0f / (millis() - t0);
      Serial.printf("%s setting %d%s  %.1f fps | capture %lu us | process %lu us | LCD %lu us | backlight %d\n",
                    colourMode ? "colour" : "gray", gainLevel, edgesOn ? " +edges" : "",
                    (float)lastFps, (unsigned long)lastCaptureUs,
                    (unsigned long)lastProcessUs, (unsigned long)lastLcdUs, blIndex);
      frames = 0;
      t0 = millis();
    }
  }
}

// Hand a finished frame to the display task. A frame still waiting there is stale,
// so it is dropped and replaced: the screen always gets the newest picture.
static void sendToDisplay(camera_fb_t *fb) {
  camera_fb_t *stale = NULL;
  if (xQueueReceive(qFrames, &stale, 0) == pdTRUE && stale) {
    esp_camera_fb_return(stale);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
  __atomic_fetch_add(&inFlight, 1, __ATOMIC_SEQ_CST);
  if (xQueueSend(qFrames, &fb, 0) != pdTRUE) {
    esp_camera_fb_return(fb);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
}
#endif

// Make sure no frame is queued or being sent (needed before restarting the camera)
static void drainDisplay() {
#if USE_PIPELINE
  camera_fb_t *stale = NULL;
  while (xQueueReceive(qFrames, &stale, 0) == pdTRUE) {
    if (stale) esp_camera_fb_return(stale);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
  while (__atomic_load_n(&inFlight, __ATOMIC_SEQ_CST) > 0) delay(1);
#endif
}

// Full camera restart: clears any stuck exposure/gain state. Used when the gain
// drops back from level 10 to level 1.
void cameraRestart() {
  drainDisplay();
  esp_camera_deinit();
  delay(50);
  if (esp_camera_init(&camCfg) != ESP_OK) {
    lcdFill(0xF81F);                 // magenta screen
    while (true) delay(1000);
  }
}

// ---------- edge highlighting ----------
static uint8_t gRowA[SCR_W], gRowB[SCR_W], gRowC[SCR_W];

static void loadRowG(const uint16_t *row, uint8_t *dst, int w) {
  for (int x = 0; x < w; x++) dst[x] = (__builtin_bswap16(row[x]) >> 5) & 63;   // 6-bit green = brightness
}

// px = big-endian RGB565 frame. Marks pixels where brightness changes sharply.
// Works one row at a time on copies of the ORIGINAL brightness, so painting
// highlights never disturbs the pixels still to be examined.
void drawEdges(uint16_t *px, int w, int h, int thr) {
  uint8_t *up = gRowA, *cur = gRowB, *down = gRowC;
  loadRowG(px, cur, w);
  memcpy(up, cur, w);                               // top edge: repeat first row
  for (int y = 0; y < h; y++) {
    if (y + 1 < h) loadRowG(px + (size_t)(y + 1) * w, down, w);
    else memcpy(down, cur, w);                      // bottom edge: repeat last row
    uint16_t *row = px + (size_t)y * w;
    for (int x = 1; x < w - 1; x++) {
      int gx = cur[x + 1] - cur[x - 1];
      int gy = down[x] - up[x];
      if (gx < 0) gx = -gx;
      if (gy < 0) gy = -gy;
      if (gx + gy > thr) {
        const uint16_t e = __builtin_bswap16(EDGE_COLOR);
        row[x] = e;
#if EDGE_THICK
        row[x + 1] = e;                              // x+1 always exists (loop stops at w-2)
        if (y + 1 < h) { row[w + x] = e; row[w + x + 1] = e; }   // and the row below
#endif
      }
    }
    uint8_t *tmp = up; up = cur; cur = down; down = tmp;
  }
}

#if CAPTURE_YUV
// ---------- YUV422 path: true 8-bit brightness for edges, conversion done here ----------
static uint8_t  yPlane[SCR_W * SCR_H];          // copy of the brightness (Y) values
static uint16_t grayLut[256];                   // brightness -> big-endian RGB565 grey

void initGrayLut() {
  for (int i = 0; i < 256; i++) {
    uint16_t c = ((i & 0xF8) << 8) | ((i & 0xFC) << 3) | (i >> 3);
    grayLut[i] = __builtin_bswap16(c);
  }
}

static inline int clamp8(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

static inline uint16_t packRgb565(int r, int g, int b) {
  r = clamp8(r); g = clamp8(g); b = clamp8(b);
  return __builtin_bswap16((uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)));
}

// ---------- horizontal-banding removal (row noise at high gain) ----------
// Each row's average brightness is compared with the average of nearby rows that have
// a similar brightness; the difference is treated as row noise and subtracted. Rows
// on the other side of a real horizontal edge differ a lot, so they are ignored and
// the edge is left alone. Bands thinner than about 9 rows disappear.
#define DEBAND_RADIUS 4     // rows either side that are compared
#define DEBAND_TOL    16    // rows differing from this row by more than this are ignored
#define DEBAND_MAX    16    // largest correction applied to any row (brightness units)
static int32_t rowMean16[SCR_H];   // row averages in 1/16 brightness units
static int8_t  rowCorr[SCR_H];

static void computeRowCorr(const uint8_t *buf, int w, int h) {
  const int yoff = YUV_ORDER_UYVY ? 1 : 0;
  for (int r = 0; r < h; r++) {
    const uint8_t *p = buf + (size_t)r * w * 2 + yoff;
    int32_t s = 0;
    for (int x = 0; x < w; x++) s += p[2 * x];
    rowMean16[r] = (s * 16 + w / 2) / w;
  }
  for (int r = 0; r < h; r++) {
    int32_t sum = 0, count = 0;
    for (int k = r - DEBAND_RADIUS; k <= r + DEBAND_RADIUS; k++) {
      if (k < 0 || k >= h || k == r) continue;
      int32_t d = rowMean16[k] - rowMean16[r];
      if (d < 0) d = -d;
      if (d <= DEBAND_TOL * 16) { sum += rowMean16[k]; count++; }
    }
    int32_t c = 0;
    if (count > 0) {
      const int32_t diff = rowMean16[r] - sum / count;                // 1/16 units
      c = (diff >= 0) ? (diff + 8) / 16 : -((-diff + 8) / 16);        // rounded
    }
    if (c > DEBAND_MAX) c = DEBAND_MAX;
    if (c < -DEBAND_MAX) c = -DEBAND_MAX;
    rowCorr[r] = (int8_t)c;
  }
}

// buf = YUV422 frame (4 bytes = 2 pixels). Converts in place to big-endian RGB565
// and keeps the brightness values in yPlane. In grayscale the colour is ignored,
// so each pixel is a single table look-up. deband = remove horizontal banding first.
void yuvToRgb565(uint8_t *buf, int w, int h, bool deband) {
  uint16_t *out = (uint16_t *)buf;
  if (deband) computeRowCorr(buf, w, h);
  for (int r = 0; r < h; r++) {
    const int c = deband ? rowCorr[r] : 0;
    const size_t base = (size_t)r * w;
    for (int x = 0; x + 1 < w; x += 2) {
      const size_t i = base + x;
#if YUV_ORDER_UYVY
      const uint8_t u = buf[2 * i], ya = buf[2 * i + 1], v = buf[2 * i + 2], yb = buf[2 * i + 3];
#else
      const uint8_t ya = buf[2 * i], u = buf[2 * i + 1], yb = buf[2 * i + 2], v = buf[2 * i + 3];
#endif
      const int y0 = clamp8((int)ya - c);
      const int y1 = clamp8((int)yb - c);
      yPlane[i] = (uint8_t)y0;
      yPlane[i + 1] = (uint8_t)y1;
      if (!colourMode) {
        out[i] = grayLut[y0];
        out[i + 1] = grayLut[y1];
      } else {
        const int du = (int)u - 128, dv = (int)v - 128;
        const int rr = (359 * dv) >> 8;
        const int gg = (88 * du + 183 * dv) >> 8;
        const int bb = (454 * du) >> 8;
        out[i]     = packRgb565(y0 + rr, y0 - gg, y0 + bb);
        out[i + 1] = packRgb565(y1 + rr, y1 - gg, y1 + bb);
      }
    }
  }
}

// Edge highlighting from the saved brightness values (the frame is already RGB565).
// smooth = Sobel-style averaging over 3 neighbours, which cuts noise from false edges.
void drawEdgesY(uint16_t *px, int w, int h, int thr, bool smooth) {
  const uint16_t e = __builtin_bswap16(EDGE_COLOR);
  for (int y = 1; y < h - 1; y++) {
    const uint8_t *r0 = yPlane + (size_t)(y - 1) * w;
    const uint8_t *r1 = yPlane + (size_t)y * w;
    const uint8_t *r2 = yPlane + (size_t)(y + 1) * w;
    uint16_t *row = px + (size_t)y * w;
    for (int x = 1; x < w - 1; x++) {
      int gx, gy;
      if (smooth) {
        gx = (r0[x + 1] + 2 * r1[x + 1] + r2[x + 1]) - (r0[x - 1] + 2 * r1[x - 1] + r2[x - 1]);
        gy = (r2[x - 1] + 2 * r2[x] + r2[x + 1]) - (r0[x - 1] + 2 * r0[x] + r0[x + 1]);
        if (gx < 0) gx = -gx;
        if (gy < 0) gy = -gy;
        gx >>= 2;
        gy >>= 2;
      } else {
        gx = r1[x + 1] - r1[x - 1];
        gy = r2[x] - r0[x];
        if (gx < 0) gx = -gx;
        if (gy < 0) gy = -gy;
      }
      if (gx + gy > thr) {
        row[x] = e;
#if EDGE_THICK
        row[x + 1] = e;
        row[w + x] = e;
        row[w + x + 1] = e;
#endif
      }
    }
  }
}
#endif

// Turn the WS2812 status LED off (needs LED_GPIO set above)
void ledsOff() {
  if (LED_GPIO >= 0) {
    neopixelWrite(LED_GPIO, 0, 0, 0);
    delay(2);
    neopixelWrite(LED_GPIO, 0, 0, 0);
  }
}

// =====================================================================
void setup() {
  Serial.begin(115200);
  pinMode(BTN_PIN, INPUT_PULLUP);

  lcdInit();
  ledsOff();
  backlightInit();
  backlightSet(BL_LEVELS[blIndex]);
  lcdFill(0x0000);

  if (!psramFound()) {
    Serial.println("PSRAM not found - set Tools > PSRAM > OPI PSRAM");
    lcdFill(0xF800);                 // red screen
    while (true) delay(1000);
  }

#if CAPTURE_YUV
  initGrayLut();
#endif
  camera_config_t &cfg = camCfg;   // global copy, so the camera can be restarted
  cfg.ledc_channel = LEDC_CHANNEL_7;   // camera clock gets its own LEDC timer/channel
  cfg.ledc_timer   = LEDC_TIMER_3;     // so it can't collide with the backlight PWM
  cfg.pin_d0 = Y2_GPIO_NUM;  cfg.pin_d1 = Y3_GPIO_NUM;
  cfg.pin_d2 = Y4_GPIO_NUM;  cfg.pin_d3 = Y5_GPIO_NUM;
  cfg.pin_d4 = Y6_GPIO_NUM;  cfg.pin_d5 = Y7_GPIO_NUM;
  cfg.pin_d6 = Y8_GPIO_NUM;  cfg.pin_d7 = Y9_GPIO_NUM;
  cfg.pin_xclk  = XCLK_GPIO_NUM;
  cfg.pin_pclk  = PCLK_GPIO_NUM;
  cfg.pin_vsync = VSYNC_GPIO_NUM;
  cfg.pin_href  = HREF_GPIO_NUM;
  cfg.pin_sccb_sda = SIOD_GPIO_NUM;
  cfg.pin_sccb_scl = SIOC_GPIO_NUM;
  cfg.pin_pwdn  = PWDN_GPIO_NUM;
  cfg.pin_reset = RESET_GPIO_NUM;
  cfg.xclk_freq_hz = 20000000;
  cfg.pixel_format = CAPTURE_YUV ? PIXFORMAT_YUV422 : PIXFORMAT_RGB565;
  cfg.frame_size   = CAM_FRAMESIZE;
  cfg.fb_count     = USE_PIPELINE ? 3 : 2;   // pipeline needs a third buffer
  cfg.fb_location  = CAMERA_FB_IN_PSRAM;
  cfg.grab_mode    = CAMERA_GRAB_LATEST;

  esp_err_t err = esp_camera_init(&cfg);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed: 0x%x\n", err);
    lcdFill(0xF81F);                 // magenta screen
    while (true) delay(1000);
  }
  applyLevel();
  ledsOff();                         // again, in case camera setup disturbed the pin

#if USE_PIPELINE
  qFrames = xQueueCreate(1, sizeof(camera_fb_t *));
  xTaskCreatePinnedToCore(displayTask, "display", 6144, NULL, 2, NULL, 0);   // core 0
#endif
}

// Returns 0 = nothing, 1 = short press, 2 = medium hold, 3 = long hold
// (reported when the button is released)
int readButton() {
  static bool down = false;
  static uint32_t tDown = 0;
  bool pressed = (digitalRead(BTN_PIN) == LOW);
  if (pressed && !down) { down = true; tDown = millis(); }
  if (!pressed && down) {
    down = false;
    uint32_t held = millis() - tDown;
    if (held > 2000) return 3;
    if (held > 800)  return 2;
    if (held > 30)   return 1;
  }
  return 0;
}

// Settings overlay, drawn on the image every frame
void drawOverlay(uint16_t *px, int w, int h, float fps) {
  ovBuf = px; ovW = w; ovH = h;
  const int y = 4;
  int x = 4;

  ovRect(x - 1, y - 1, 12, 12, 0x0000);                        // palette square + border
  ovRect(x, y, 10, 10, colourMode ? 0xFD20 : 0xBDF7);          // orange = colour, grey = grayscale
  x += 16;

  if (gainLevel < NUM_LOW) {                                   // low-gain settings: L1-L4
    ovGlyph(x, y, 11, 0x07FF);
    ovGlyph(x + 8, y, gainLevel + 1, 0x07FF);
    x += 16;
  } else if (gainLevel >= NUM_LOW + NUM_NIGHT) {               // capped exposure: F1-F3, B1-B3
    int k = gainLevel - (NUM_LOW + NUM_NIGHT);
    ovGlyph(x, y, k < 3 ? 12 : 13, 0x07FF);                    // F or B
    ovGlyph(x + 8, y, (k % 3) + 1, 0x07FF);
    x += 16;
  } else {
    int lvl = gainLevel - NUM_LOW + 1;                         // night levels 1-10
    if (lvl >= 10) {
      ovGlyph(x, y, 1, 0x07FF);
      ovGlyph(x + 8, y, 0, 0x07FF);
      x += 16;
    } else {
      ovGlyph(x, y, lvl, 0x07FF);
      x += 8;
    }
  }
  if (edgesOn) { ovGlyph(x + 2, y, 10, 0xFFE0); x += 10; }     // yellow E = edges on
  x += 3;
  ovRect(x - 1, y + 3, 6, 4, 0x0000);                          // small dash between setting and fps
  ovRect(x, y + 4, 4, 2, 0x7BEF);
  x += 8;

  int f = (int)(fps + 0.5f);                                   // frames per second
  if (f > 99) f = 99;
  if (f >= 10) { ovGlyph(x, y, f / 10, 0x07E0); x += 8; }
  ovGlyph(x, y, f % 10, 0x07E0);

  const int xb = w - 30;                                       // backlight bars, top-right
  ovRect(xb - 1, y - 1, 28, 12, 0x0000);
  for (int i = 0; i < 4; i++)
    ovRect(xb + i * 7, y, 5, 10, (i < 4 - blIndex) ? 0xFFFF : 0x4208);
}

void loop() {
#if !USE_PIPELINE
  static uint32_t frames = 0, t0 = millis();
#endif

  int b = readButton();
  if (b == 1) {
    gainLevel = (gainLevel + 1) % NUM_LEVELS;
    if (gainLevel == 0) {                 // wrapped round to the start: toggle edges, restart camera
      edgesOn = !edgesOn;
      cameraRestart();
    }
    applyLevel();
  }
  if (b == 2) { blIndex = (blIndex + 1) % 4; backlightSet(BL_LEVELS[blIndex]); }
  if (b == 3) { colourMode = !colourMode; applyLevel(); }

  uint32_t captureStartUs = micros();
  camera_fb_t *fb = esp_camera_fb_get();
  lastCaptureUs = micros() - captureStartUs;
  if (!fb) return;

  if (fb->width > SCR_W || fb->height > SCR_H) {           // frame doesn't fit the screen
    esp_camera_fb_return(fb);
    return;
  }

  uint32_t processStartUs = micros();
#if CAPTURE_YUV
  const LevelDef &lv = LEVELS[gainLevel];
  const int thr = lv.edge * EDGE_SCALE / 100;
  yuvToRgb565(fb->buf, fb->width, fb->height, lv.clean);        // also saves brightness for edges
  if (edgesOn) drawEdgesY((uint16_t *)fb->buf, fb->width, fb->height, thr, lv.clean);
#else
#if SWAP_BYTES
  for (size_t i = 0; i + 1 < fb->len; i += 2) { uint8_t t = fb->buf[i]; fb->buf[i] = fb->buf[i + 1]; fb->buf[i + 1] = t; }
#endif
  {
    int thr6 = LEVELS[gainLevel].edge * EDGE_SCALE / 100 / 4;     // RGB565 green is 6-bit
    if (thr6 < 1) thr6 = 1;
    if (edgesOn) drawEdges((uint16_t *)fb->buf, fb->width, fb->height, thr6);
  }
#endif
  drawOverlay((uint16_t *)fb->buf, fb->width, fb->height, lastFps);
  lastProcessUs = micros() - processStartUs;

#if USE_PIPELINE
  sendToDisplay(fb);                       // display task sends it and returns the buffer
#else
  uint16_t x0 = (SCR_W - fb->width) / 2;
  uint16_t y0 = (SCR_H - fb->height) / 2;                  // centred vertically
  lcdPush(x0, y0, fb->width, fb->height, fb->buf);
  esp_camera_fb_return(fb);

  frames++;
  if (millis() - t0 >= 1000) {
    lastFps = frames * 1000.0f / (millis() - t0);
    Serial.printf("%s setting %d%s  %.1f fps  backlight step %d\n",
                  colourMode ? "colour" : "gray", gainLevel, edgesOn ? " +edges" : "", (float)lastFps, blIndex);
    frames = 0;
    t0 = millis();
  }
#endif
}
