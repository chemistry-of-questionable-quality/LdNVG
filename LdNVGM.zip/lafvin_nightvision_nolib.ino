// Near-IR night vision monocular -- LAFVIN ESP32-S3 1.69" LCD board
// Works with an OV3660 or an OV5640 camera: the camera driver detects which one is
// fitted. For about 6 seconds after start-up the sensor ID is shown on screen
// (3660 = OV3660, 5640 = OV5640).
// NO EXTRA LIBRARIES: uses only SPI.h and esp_camera.h from the ESP32 core,
// with a small built-in ST7789 driver.
//
// 20 settings, each with and without EDGE HIGHLIGHTING:
//   L1-L4 = low-gain settings for bright / supplemental IR (L1 dimmest)
//   1-10  = night gain levels (10 = the old BOOST setting)
//   F1-F3 = capped exposure, modest gain: higher frame rate
//   B1-B3 = capped exposure, boosted gain: higher frame rate, brighter, grainier
// After the last setting the cycle repeats all of them with edge highlighting on,
// then goes back to plain again.
//
// BOOT button (GPIO0), normal mode:
//   short press (under 0.8 s) = next setting
//   medium hold (0.8 - 2 s)   = cycle LCD backlight (100% -> 50% -> 15% -> 4%)
//   long hold   (over 2 s)    = open the MENU
// BOOT button, inside the MENU (a panel appears on the picture):
//   short press = change the value of the selected row
//   medium hold = move to the other row
//   long hold   = close the menu
//   Row F = picture filter / tint: grey, green, amber, red, blue, colour
//   Row E = edge highlight colour: yellow, red, green, cyan, magenta, white
//   Row M = stationary observation (motion detection + tracking): off / on
//   Row S = motion sensitivity 1-5 (5 = most sensitive)
//
// Status overlay (drawn on the image, top-left; backlight bars top-right):
//   square          = current filter colour
//   first number    = setting L1-L4, 1-10, F1-F3 or B1-B3 (cyan), "E" after it = edges on
//   second number   = frames per second (green)
//   4 bars (right)  = backlight level
//
// Board settings: ESP32S3 Dev Module, PSRAM = OPI PSRAM.
// Start-up error colours: RED screen = no PSRAM, MAGENTA = camera init failed.
//
// Speed-ups (set to 0 to turn off if anything misbehaves):
//   USE_PIPELINE : camera capture + processing run on one CPU core while the other
//                  core sends the previous frame to the screen
//   USE_DMA_SPI  : screen transfer uses DMA (falls back to the plain SPI library
//                  automatically if DMA is unavailable or fails to start)

#define USE_PIPELINE 1
#define USE_DMA_SPI  1

// 1 = capture YUV422 and convert to RGB565 on the ESP32, with edge detection working
// on true 8-bit brightness (looked better in testing). 0 = camera outputs RGB565.
#define CAPTURE_YUV  1
// If CAPTURE_YUV is 1 and the picture looks wrong (grainy/striped or odd colours),
// try 1 here: it switches the expected byte order from YUYV to UYVY.
#define YUV_ORDER_UYVY 0

#include <SPI.h>
#include "esp_camera.h"

#if USE_DMA_SPI && defined(__has_include)
#if __has_include(<driver/spi_master.h>)
#include <driver/spi_master.h>
#include <esp_heap_caps.h>
#define LCD_DMA 1
#endif
#endif
#ifndef LCD_DMA
#define LCD_DMA 0
#endif

// OV5640 autofocus. Only used if (a) an OV5640 is detected, (b) its lens has autofocus and
// (c) the "OV5640 Auto Focus for ESP32 Camera" library is installed. Otherwise ignored.
#define USE_OV5640_AF 1
#if USE_OV5640_AF && defined(__has_include)
#if __has_include("ESP32_OV5640_AF.h")
#include "ESP32_OV5640_AF.h"
#define OV5640_AF_AVAILABLE 1
#endif
#endif
#ifndef OV5640_AF_AVAILABLE
#define OV5640_AF_AVAILABLE 0
#endif

// 1 = ask the compiler to optimise this sketch for speed (the ESP32 core normally
// optimises for size). Set to 0 if the build complains.
#define FORCE_SPEED_OPT 1
#if FORCE_SPEED_OPT
#pragma GCC optimize ("O3")
#endif

// ---------- LCD pins ----------
#define TFT_MOSI 39
#define TFT_SCLK 38
#define TFT_CS   14
#define TFT_DC   10
#define TFT_RST  3
#define TFT_BL   13
#define BTN_PIN  0

#define SPI_HZ   80000000   // lower to 40000000 if the picture glitches
#define ROW_OFF  20         // 240x280 panel sits 20 rows into the controller RAM
#define SCR_W    240
#define SCR_H    280
#define STRIP_H  20         // work-buffer height used when clearing the screen
// Camera resolution. 240x240 fills the screen width. Smaller sizes (for example
// FRAMESIZE_HQVGA = 240x176, FRAMESIZE_QQVGA = 160x120) leave black borders; the
// picture is always centred on the screen.
#define CAM_FRAMESIZE FRAMESIZE_240X240
#define SWAP_BYTES 0        // set to 1 if red and blue look swapped

// ---------- Camera pins (the board's camera connector; same for OV3660 and OV5640) ----------
#define PWDN_GPIO_NUM   -1
#define RESET_GPIO_NUM  -1
#define XCLK_GPIO_NUM   17
#define SIOD_GPIO_NUM   1
#define SIOC_GPIO_NUM   2
#define VSYNC_GPIO_NUM  21
#define HREF_GPIO_NUM   18
#define PCLK_GPIO_NUM   16
#define Y2_GPIO_NUM     7
#define Y3_GPIO_NUM     5
#define Y4_GPIO_NUM     4
#define Y5_GPIO_NUM     6
#define Y6_GPIO_NUM     8
#define Y7_GPIO_NUM     9
#define Y8_GPIO_NUM     11
#define Y9_GPIO_NUM     15

// Flip these if the image is upside down / mirrored in your housing
#define IMG_VFLIP    1
#define IMG_HMIRROR  0
// The OV5640 needs both flips to come out the right way round. These are used
// automatically when an OV5640 is detected (the OV3660 uses the two lines above).
#define OV5640_VFLIP    1
#define OV5640_HMIRROR  1

// Status LED (WS2812) on the board: GPIO 48 per Lafvin's pin_config.h.
// Set to -1 to leave the LED alone.
#define LED_GPIO 48

// Edge highlighting. Each setting has its own sensitivity in the table below.
// EDGE_SCALE adjusts them all at once, in percent: below 100 = more edges (and more
// noise), above 100 = fewer edges.
#define EDGE_SCALE     100
#define EDGE_THICK     0        // 0 = 1-pixel highlights, 1 = 2 pixels thick

// =====================================================================
//  Minimal ST7789 driver
// =====================================================================
SPIClass lcdSPI(HSPI);
static const SPISettings lcdSettings(SPI_HZ, MSBFIRST, SPI_MODE0);
static uint8_t stripBuf[SCR_W * STRIP_H * 2];   // 9600 bytes, used for clearing the screen

// ---------- low-level SPI backend: DMA if available, otherwise the SPI library ----------
#if LCD_DMA
#define DMA_CHUNK 8192                 // bytes per DMA transfer (even number)
static spi_device_handle_t lcdDev = NULL;
static uint8_t *dmaBuf[2] = {NULL, NULL};
static spi_transaction_t dmaTrans[2];
static bool useDma = false;

static bool dmaInit() {
  spi_bus_config_t bus = {};
  bus.mosi_io_num = TFT_MOSI;
  bus.miso_io_num = -1;
  bus.sclk_io_num = TFT_SCLK;
  bus.quadwp_io_num = -1;
  bus.quadhd_io_num = -1;
  bus.max_transfer_sz = DMA_CHUNK;
  if (spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO) != ESP_OK) return false;

  const uint32_t speeds[2] = {SPI_HZ, 40000000};   // try the full speed, then 40 MHz
  for (int i = 0; i < 2 && !lcdDev; i++) {
    spi_device_interface_config_t dev = {};
    dev.clock_speed_hz = speeds[i];
    dev.mode = 0;
    dev.spics_io_num = -1;             // chip-select is driven by hand
    dev.queue_size = 2;
    if (spi_bus_add_device(SPI2_HOST, &dev, &lcdDev) != ESP_OK) lcdDev = NULL;
  }
  if (!lcdDev) { spi_bus_free(SPI2_HOST); return false; }

  for (int i = 0; i < 2; i++)
    dmaBuf[i] = (uint8_t *)heap_caps_malloc(DMA_CHUNK, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
  if (!dmaBuf[0] || !dmaBuf[1]) {
    for (int i = 0; i < 2; i++) { if (dmaBuf[i]) heap_caps_free(dmaBuf[i]); dmaBuf[i] = NULL; }
    spi_bus_remove_device(lcdDev);
    lcdDev = NULL;
    spi_bus_free(SPI2_HOST);
    return false;
  }
  return true;
}
#endif

static void spiInit() {
#if LCD_DMA
  useDma = dmaInit();
  if (useDma) return;
#endif
  lcdSPI.begin(TFT_SCLK, -1, TFT_MOSI, -1);
}

// Sends n bytes. With DMA: copies 8 KB pieces into internal memory and queues them,
// so the copy of one piece overlaps the DMA transfer of the previous one.
static void spiWrite(const uint8_t *d, size_t n) {
#if LCD_DMA
  if (useDma) {
    int inflight = 0, idx = 0;
    size_t off = 0;
    while (off < n) {
      size_t len = n - off;
      if (len > DMA_CHUNK) len = DMA_CHUNK;
      if (inflight == 2) {                               // both buffers busy: wait for the older one
        spi_transaction_t *done;
        spi_device_get_trans_result(lcdDev, &done, portMAX_DELAY);
        inflight--;
      }
      memcpy(dmaBuf[idx], d + off, len);
      memset(&dmaTrans[idx], 0, sizeof(spi_transaction_t));
      dmaTrans[idx].length = len * 8;                    // length is in bits
      dmaTrans[idx].tx_buffer = dmaBuf[idx];
      spi_device_queue_trans(lcdDev, &dmaTrans[idx], portMAX_DELAY);
      inflight++;
      idx ^= 1;
      off += len;
    }
    while (inflight > 0) {
      spi_transaction_t *done;
      spi_device_get_trans_result(lcdDev, &done, portMAX_DELAY);
      inflight--;
    }
    return;
  }
#endif
  lcdSPI.beginTransaction(lcdSettings);
  lcdSPI.writeBytes(d, n);
  lcdSPI.endTransaction();
}

void lcdCmd(uint8_t c) {
  digitalWrite(TFT_DC, LOW);
  digitalWrite(TFT_CS, LOW);
  spiWrite(&c, 1);
  digitalWrite(TFT_CS, HIGH);
}

void lcdData(const uint8_t *d, size_t n) {
  digitalWrite(TFT_DC, HIGH);
  digitalWrite(TFT_CS, LOW);
  spiWrite(d, n);
  digitalWrite(TFT_CS, HIGH);
}

void lcdCmdData(uint8_t c, const uint8_t *d, size_t n) {
  lcdCmd(c);
  if (n) lcdData(d, n);
}

#define CMD(c, ...) do { const uint8_t d_[] = {__VA_ARGS__}; lcdCmdData(c, d_, sizeof(d_)); } while (0)

void lcdSetWindow(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1) {
  y0 += ROW_OFF;
  y1 += ROW_OFF;
  CMD(0x2A, (uint8_t)(x0 >> 8), (uint8_t)x0, (uint8_t)(x1 >> 8), (uint8_t)x1);
  CMD(0x2B, (uint8_t)(y0 >> 8), (uint8_t)y0, (uint8_t)(y1 >> 8), (uint8_t)y1);
  lcdCmd(0x2C);   // memory write
}

// data = big-endian RGB565 (high byte first)
void lcdPush(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint8_t *data) {
  lcdSetWindow(x, y, x + w - 1, y + h - 1);
  lcdData(data, (size_t)w * h * 2);
}

void lcdInit() {
  pinMode(TFT_DC, OUTPUT);
  pinMode(TFT_CS, OUTPUT);
  pinMode(TFT_RST, OUTPUT);
  digitalWrite(TFT_CS, HIGH);
  spiInit();

  digitalWrite(TFT_RST, HIGH); delay(10);
  digitalWrite(TFT_RST, LOW);  delay(20);
  digitalWrite(TFT_RST, HIGH); delay(120);

  lcdCmd(0x01); delay(150);          // software reset
  lcdCmd(0x11); delay(120);          // sleep out
  CMD(0x3A, 0x55);                   // 16-bit colour
  CMD(0x36, 0x00);                   // orientation / RGB order
  CMD(0xB2, 0x0C, 0x0C, 0x00, 0x33, 0x33);
  CMD(0xB7, 0x35);
  CMD(0xBB, 0x19);
  CMD(0xC0, 0x2C);
  CMD(0xC2, 0x01);
  CMD(0xC3, 0x12);
  CMD(0xC4, 0x20);
  CMD(0xC6, 0x0F);
  CMD(0xD0, 0xA4, 0xA1);
  CMD(0xE0, 0xD0, 0x04, 0x0D, 0x11, 0x13, 0x2B, 0x3F, 0x54, 0x4C, 0x18, 0x0D, 0x0B, 0x1F, 0x23);
  CMD(0xE1, 0xD0, 0x04, 0x0C, 0x11, 0x13, 0x2C, 0x3F, 0x44, 0x51, 0x2F, 0x1F, 0x1F, 0x20, 0x23);
  lcdCmd(0x21);                      // display inversion on (needed for this IPS panel)
  lcdCmd(0x13);                      // normal mode
  lcdCmd(0x29);                      // display on
  delay(20);
}

// Fill the whole screen with one RGB565 colour
void lcdFill(uint16_t color) {
  for (size_t i = 0; i < sizeof(stripBuf); i += 2) {
    stripBuf[i] = color >> 8;
    stripBuf[i + 1] = color & 0xFF;
  }
  for (int y = 0; y < SCR_H; y += STRIP_H) lcdPush(0, y, SCR_W, STRIP_H, stripBuf);
}

// =====================================================================
//  On-image overlay helpers (draw straight into the camera frame, big-endian RGB565)
// =====================================================================
// 3x5 digit font, 15 bits each (row-major, MSB = top-left)
static const uint16_t DIGITS[15] = {0x7B6F, 0x2C97, 0x73E7, 0x73CF, 0x5BC9,
                                    0x79CF, 0x79EF, 0x7249, 0x7BEF, 0x7BCF,
                                    0x79E7 /* 10 = E */, 0x4927 /* 11 = L */,
                                    0x79E4 /* 12 = F */, 0x6BAE /* 13 = B */,
                                    0x5FED /* 14 = M */};
static uint16_t *ovBuf;
static int ovW, ovH;

static void ovPix(int x, int y, uint16_t c) {
  if (x < 0 || x >= ovW || y < 0 || y >= ovH) return;
  ovBuf[(size_t)y * ovW + x] = __builtin_bswap16(c);
}
static void ovRect(int x, int y, int w, int h, uint16_t c) {
  for (int yy = 0; yy < h; yy++) for (int xx = 0; xx < w; xx++) ovPix(x + xx, y + yy, c);
}
// Glyph drawn at 2x size with a black drop-shadow so it stays readable on any picture
static void ovGlyph(int x, int y, int idx, uint16_t c) {
  uint16_t g = DIGITS[idx];
  for (int pass = 0; pass < 2; pass++)
    for (int r = 0; r < 5; r++)
      for (int col = 0; col < 3; col++)
        if (g & (1 << (14 - (r * 3 + col))))
          ovRect(x + col * 2 + (pass == 0), y + r * 2 + (pass == 0), 2, 2, pass == 0 ? 0x0000 : c);
}

// =====================================================================
//  Backlight PWM (works on Arduino-ESP32 core 2.x and 3.x)
// =====================================================================
static const uint8_t BL_LEVELS[] = {255, 128, 38, 10};
static uint8_t blIndex = 0;

void backlightInit() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(TFT_BL, 5000, 8);
#else
  ledcSetup(0, 5000, 8);
  ledcAttachPin(TFT_BL, 0);
#endif
}
void backlightSet(uint8_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(TFT_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}

// =====================================================================
//  Gain levels (10 grayscale + 10 colour)
// =====================================================================
#define NUM_LEVELS 20
#define NUM_LOW    4     // entries 0-3   = L1..L4 (low gain for bright / supplemental IR)
#define NUM_NIGHT  10    // entries 4-13  = night levels 1..10
                         // entries 14-16 = F1..F3 (capped exposure, modest gain)
                         // entries 17-19 = B1..B3 (capped exposure, boosted gain)

// Capped-exposure values for F1-F3 and B1-B3. The camera is told to use exactly this
// exposure, so the frame rate stays high. Bigger number = longer exposure = brighter
// but slower. The units are sensor lines; the camera driver limits the value to one
// frame. If F3/B3 show a lower fps than F2/B2, lower EXP_LONG.
#define EXP_SHORT  150
#define EXP_MED    350
#define EXP_LONG   1200

// One row per setting.
//   gain   : manual camera gain (0-30)
//   ae     : auto-exposure target (-2 darker .. +2 brighter), used when exp = 0
//   bright : brightness (-2..2)
//   aec2   : 1 = sensor night-mode exposure (can slow the frame rate), 0 = off
//   exp    : 0 = automatic exposure, otherwise a fixed (capped) exposure
//   edge   : edge-detection threshold on a 0-255 brightness scale (lower = more sensitive)
//   clean  : 1 = noise clean-up for high-gain settings: removes horizontal banding
//            from the picture and uses smoother edge detection (YUV mode only for banding)
struct LevelDef { int8_t gain, ae, bright, aec2; int16_t exp; int16_t edge; int8_t clean; };
static const LevelDef LEVELS[NUM_LEVELS] = {
  {  0,  0,  0, 0, 0, 12, 0 },   // L1  (brightest IR scenes)
  {  1,  1,  0, 0, 0, 14, 0 },   // L2
  {  2,  1,  1, 0, 0, 18, 0 },   // L3
  {  4,  2,  1, 0, 0, 22, 0 },   // L4
  {  6,  2,  2, 1, 0, 32, 0 },   // 1
  {  9,  2,  2, 1, 0, 32, 0 },   // 2
  { 11,  2,  2, 1, 0, 32, 0 },   // 3
  { 13,  2,  2, 1, 0, 32, 0 },   // 4
  { 15,  2,  2, 1, 0, 32, 0 },   // 5
  { 18,  2,  2, 1, 0, 32, 0 },   // 6
  { 21,  2,  2, 1, 0, 32, 0 },   // 7
  { 24,  2,  2, 1, 0, 32, 0 },   // 8
  { 27,  2,  2, 1, 0, 32, 0 },   // 9
  { 30,  2,  2, 1, 0, 32, 0 },   // 10 = old BOOST
  {  8,  0,  2, 0, EXP_SHORT, 32, 0 },   // F1  fast, modest gain
  {  8,  0,  2, 0, EXP_MED,   32, 0 },   // F2
  {  8,  0,  2, 0, EXP_LONG,  32, 0 },   // F3
  { 30,  0,  2, 0, EXP_SHORT, 46, 1 },   // B1  fast, boosted gain (noisy: less sensitive edges + clean-up)
  { 30,  0,  2, 0, EXP_MED,   42, 1 },   // B2
  { 30,  0,  2, 0, EXP_LONG,  38, 1 },   // B3
};

static int  gainLevel  = 8;      // 0-based index into LEVELS, so this is night level 5
// ---------- picture filters and edge colours (chosen in the menu) ----------
#define NUM_FILTERS      6
#define FILTER_COLOUR    5          // the last filter = real colour
#define NUM_EDGE_COLORS  6
// Tint colour (R, G, B) for each filter. Brightness is mapped onto this colour.
static const uint8_t TINT[NUM_FILTERS][3] = {
  {255, 255, 255},   // 0 grey
  { 40, 255,  60},   // 1 green (night-vision phosphor)
  {255, 170,  30},   // 2 amber
  {255,  40,  30},   // 3 red (best for keeping your eyes dark-adapted)
  { 70, 170, 255},   // 4 blue
  {  0,   0,   0},   // 5 colour (not a tint)
};
// Edge highlight colours, RGB565: yellow, red, green, cyan, magenta, white
static const uint16_t EDGE_COLORS[NUM_EDGE_COLORS] = {0xFFE0, 0xF800, 0x07E0, 0x07FF, 0xF81F, 0xFFFF};

static int  filterIdx    = 0;
static int  edgeColorIdx = 0;
static bool menuOpen     = false;
static int  menuItem     = 0;      // 0 = filter row, 1 = edge colour row
static uint16_t sensorPid = 0;         // camera sensor ID (0x3660 = OV3660, 0x5640 = OV5640)
static uint32_t bootShowUntil = 0;     // show the sensor ID on screen until this time
static inline uint16_t rgb565(int r, int g, int b) { return (uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)); }

// ---------- stationary observation: motion detection and tracking ----------
// Works best with the camera held still (mounted or braced). The picture is split into
// 4x4-pixel blocks; each block is compared with a slowly updating background. Changed
// blocks are grouped into objects, and objects are followed from frame to frame.
// Needs CAPTURE_YUV 1 (the default). For the steadiest result use a setting with fixed
// exposure (F1-F3 or B1-B3) so automatic exposure doesn't change the whole picture.
#define MB          4                   // block size in pixels (the code assumes 4)
#define GW_MAX      (SCR_W / MB)        // 60 blocks across
#define GH_MAX      (SCR_H / MB)        // 70 blocks down
#define MAXTRK      4                   // objects followed at once
#define MAXDET      8                   // objects found per frame
#define TRAIL_LEN   8                   // positions kept for the trail
static bool motionOn    = false;
static int  motionSens  = 2;            // 0..4, shown as 1-5
static bool motionReset = true;         // rebuild the background on the next frame
static int  motionWarm  = 0;            // frames left before detection starts
static int  confirmedTracks = 0;        // objects currently being followed
static const uint8_t MOTION_THR[5]    = {28, 22, 16, 12, 9};   // brightness change needed (0-255)
static const uint8_t MOTION_MINBLK[5] = { 6,  5,  4,  3, 2};   // smallest object, in blocks

struct MotionTrack { bool used; bool tall; bool moved; uint8_t age, miss, tn, still; int16_t x0, y0, x1, y1, cx, cy, ax, ay; int16_t tx[TRAIL_LEN], ty[TRAIL_LEN]; };
// Objects that stop moving are dropped and absorbed into the background after this many
// frames: quickly for something that never moved (a leftover ghost), slowly for something
// that was seen moving first.
#define STILL_NEW_LIMIT    40
#define STILL_MOVED_LIMIT  150
struct MotionDet   { int16_t x0, y0, x1, y1, cx, cy, n; };
static MotionTrack tracks[MAXTRK];
static bool edgesOn    = false;  // edge highlighting
static camera_config_t camCfg;   // kept so the camera can be restarted
static volatile float lastFps = 0;   // written by the display side, read by the overlay

// Call a sensor function only if this sensor driver implements it.
#define SET(fn, ...) do { if (s->fn) s->fn(s, __VA_ARGS__); } while (0)

void applyLevel() {
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return;

  motionReset = true;                          // brightness changes: relearn the background
  const bool is5640 = (sensorPid == 0x5640);
  SET(set_vflip, is5640 ? OV5640_VFLIP : IMG_VFLIP);
  SET(set_hmirror, is5640 ? OV5640_HMIRROR : IMG_HMIRROR);
  SET(set_lenc, 1);

  if (filterIdx == FILTER_COLOUR) {
    SET(set_special_effect, 0);    // normal colour
    SET(set_whitebal, 1);
    SET(set_awb_gain, 1);
    SET(set_saturation, 0);
  } else {
#if CAPTURE_YUV
    SET(set_special_effect, 2);    // grayscale; the tint is added in software
#else
    static const uint8_t SENSOR_FX[NUM_FILTERS] = {2, 4, 6, 3, 5, 0};   // grey, green, sepia, red, blue
    SET(set_special_effect, SENSOR_FX[filterIdx]);                     // (tints done by the camera)
#endif
    SET(set_whitebal, 0);
    SET(set_awb_gain, 0);
    SET(set_saturation, -2);
  }

  const LevelDef &d = LEVELS[gainLevel];
  SET(set_gain_ctrl, 0);                       // manual gain...
  SET(set_agc_gain, d.gain);                   // ...stepped by level
  if (d.exp > 0) {
    SET(set_exposure_ctrl, 0);                 // fixed exposure: keeps the frame rate up
    SET(set_aec_value, d.exp);
  } else {
    SET(set_exposure_ctrl, 1);                 // exposure stays automatic
  }
  SET(set_aec2, d.aec2);
  SET(set_ae_level, d.ae);
  SET(set_gainceiling, GAINCEILING_128X);
  SET(set_brightness, d.bright);
  SET(set_contrast, 1);
}

// ---------- two-core pipeline: core 1 captures/processes, core 0 sends to the screen ----------
#if USE_PIPELINE
static QueueHandle_t qFrames = NULL;     // holds at most one frame waiting for the screen
static int inFlight = 0;                 // frames queued or currently being sent

static void displayTask(void *arg) {
  (void)arg;
  uint32_t frames = 0, t0 = millis();
  for (;;) {
    camera_fb_t *fb = NULL;
    if (xQueueReceive(qFrames, &fb, portMAX_DELAY) != pdTRUE || !fb) continue;
    uint16_t x0 = (SCR_W - fb->width) / 2;
    uint16_t y0 = (SCR_H - fb->height) / 2;          // centred vertically
    lcdPush(x0, y0, fb->width, fb->height, fb->buf);
    esp_camera_fb_return(fb);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);

    frames++;
    if (millis() - t0 >= 1000) {
      lastFps = frames * 1000.0f / (millis() - t0);
      Serial.printf("filter %d setting %d%s  %.1f fps  backlight step %d\n",
                    filterIdx, gainLevel, edgesOn ? " +edges" : "", (float)lastFps, blIndex);
      frames = 0;
      t0 = millis();
    }
  }
}

// Hand a finished frame to the display task. A frame still waiting there is stale,
// so it is dropped and replaced: the screen always gets the newest picture.
static void sendToDisplay(camera_fb_t *fb) {
  camera_fb_t *stale = NULL;
  if (xQueueReceive(qFrames, &stale, 0) == pdTRUE && stale) {
    esp_camera_fb_return(stale);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
  __atomic_fetch_add(&inFlight, 1, __ATOMIC_SEQ_CST);
  if (xQueueSend(qFrames, &fb, 0) != pdTRUE) {
    esp_camera_fb_return(fb);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
}
#endif

// Make sure no frame is queued or being sent (needed before restarting the camera)
static void drainDisplay() {
#if USE_PIPELINE
  camera_fb_t *stale = NULL;
  while (xQueueReceive(qFrames, &stale, 0) == pdTRUE) {
    if (stale) esp_camera_fb_return(stale);
    __atomic_fetch_sub(&inFlight, 1, __ATOMIC_SEQ_CST);
  }
  while (__atomic_load_n(&inFlight, __ATOMIC_SEQ_CST) > 0) delay(1);
#endif
}

// Start continuous autofocus on an OV5640 with an autofocus lens (needs the library, see top)
static void startAutofocus() {
#if OV5640_AF_AVAILABLE
  if (sensorPid != 0x5640) return;
  static OV5640 ov5640;
  sensor_t *s = esp_camera_sensor_get();
  if (!s) return;
  ov5640.start(s);
  if (ov5640.focusInit() == 0) ov5640.autoFocusMode();
#endif
}

// Full camera restart: clears any stuck exposure/gain state. Used when the gain
// drops back from level 10 to level 1.
void cameraRestart() {
  drainDisplay();
  esp_camera_deinit();
  delay(50);
  if (esp_camera_init(&camCfg) != ESP_OK) {
    lcdFill(0xF81F);                 // magenta screen
    while (true) delay(1000);
  }
  startAutofocus();
  motionReset = true;
}

// ---------- edge highlighting ----------
static uint8_t gRowA[SCR_W], gRowB[SCR_W], gRowC[SCR_W];

static void loadRowG(const uint16_t *row, uint8_t *dst, int w) {
  for (int x = 0; x < w; x++) dst[x] = (__builtin_bswap16(row[x]) >> 5) & 63;   // 6-bit green = brightness
}

// px = big-endian RGB565 frame. Marks pixels where brightness changes sharply.
// Works one row at a time on copies of the ORIGINAL brightness, so painting
// highlights never disturbs the pixels still to be examined.
void drawEdges(uint16_t *px, int w, int h, int thr) {
  uint8_t *up = gRowA, *cur = gRowB, *down = gRowC;
  loadRowG(px, cur, w);
  memcpy(up, cur, w);                               // top edge: repeat first row
  for (int y = 0; y < h; y++) {
    if (y + 1 < h) loadRowG(px + (size_t)(y + 1) * w, down, w);
    else memcpy(down, cur, w);                      // bottom edge: repeat last row
    uint16_t *row = px + (size_t)y * w;
    for (int x = 1; x < w - 1; x++) {
      int gx = cur[x + 1] - cur[x - 1];
      int gy = down[x] - up[x];
      if (gx < 0) gx = -gx;
      if (gy < 0) gy = -gy;
      if (gx + gy > thr) {
        const uint16_t e = __builtin_bswap16(EDGE_COLORS[edgeColorIdx]);
        row[x] = e;
#if EDGE_THICK
        row[x + 1] = e;                              // x+1 always exists (loop stops at w-2)
        if (y + 1 < h) { row[w + x] = e; row[w + x + 1] = e; }   // and the row below
#endif
      }
    }
    uint8_t *tmp = up; up = cur; cur = down; down = tmp;
  }
}

#if CAPTURE_YUV
// ---------- YUV422 path: true 8-bit brightness for edges, conversion done here ----------
static uint8_t  yPlane[SCR_W * SCR_H];          // copy of the brightness (Y) values
static uint16_t tintLut[NUM_FILTERS][256];      // brightness -> big-endian RGB565, one table per tint

void initTintLuts() {
  for (int f = 0; f < NUM_FILTERS; f++)
    for (int i = 0; i < 256; i++) {
      int r = i * TINT[f][0] / 255, g = i * TINT[f][1] / 255, bl = i * TINT[f][2] / 255;
      tintLut[f][i] = __builtin_bswap16(rgb565(r, g, bl));
    }
}

static inline int clamp8(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

static inline uint16_t packRgb565(int r, int g, int b) {
  r = clamp8(r); g = clamp8(g); b = clamp8(b);
  return __builtin_bswap16((uint16_t)(((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)));
}

// ---------- horizontal-banding removal (row noise at high gain) ----------
// Each row's average brightness is compared with the average of nearby rows that have
// a similar brightness; the difference is treated as row noise and subtracted. Rows
// on the other side of a real horizontal edge differ a lot, so they are ignored and
// the edge is left alone. Bands thinner than about 9 rows disappear.
#define DEBAND_RADIUS 4     // rows either side that are compared
#define DEBAND_TOL    16    // rows differing from this row by more than this are ignored
#define DEBAND_MAX    16    // largest correction applied to any row (brightness units)
static int32_t rowMean16[SCR_H];   // row averages in 1/16 brightness units
static int8_t  rowCorr[SCR_H];

static void computeRowCorr(const uint8_t *buf, int w, int h) {
  const int yoff = YUV_ORDER_UYVY ? 1 : 0;
  for (int r = 0; r < h; r++) {
    const uint8_t *p = buf + (size_t)r * w * 2 + yoff;
    int32_t s = 0;
    for (int x = 0; x < w; x++) s += p[2 * x];
    rowMean16[r] = (s * 16 + w / 2) / w;
  }
  for (int r = 0; r < h; r++) {
    int32_t sum = 0, count = 0;
    for (int k = r - DEBAND_RADIUS; k <= r + DEBAND_RADIUS; k++) {
      if (k < 0 || k >= h || k == r) continue;
      int32_t d = rowMean16[k] - rowMean16[r];
      if (d < 0) d = -d;
      if (d <= DEBAND_TOL * 16) { sum += rowMean16[k]; count++; }
    }
    int32_t c = 0;
    if (count > 0) {
      const int32_t diff = rowMean16[r] - sum / count;                // 1/16 units
      c = (diff >= 0) ? (diff + 8) / 16 : -((-diff + 8) / 16);        // rounded
    }
    if (c > DEBAND_MAX) c = DEBAND_MAX;
    if (c < -DEBAND_MAX) c = -DEBAND_MAX;
    rowCorr[r] = (int8_t)c;
  }
}

// buf = YUV422 frame (4 bytes = 2 pixels). Converts in place to big-endian RGB565
// and keeps the brightness values in yPlane. In grayscale the colour is ignored,
// so each pixel is a single table look-up (this is also how tints work). deband = remove horizontal banding first.
void yuvToRgb565(uint8_t *buf, int w, int h, bool deband) {
  uint16_t *out = (uint16_t *)buf;
  if (deband) computeRowCorr(buf, w, h);
  for (int r = 0; r < h; r++) {
    const int c = deband ? rowCorr[r] : 0;
    const size_t base = (size_t)r * w;
    for (int x = 0; x + 1 < w; x += 2) {
      const size_t i = base + x;
#if YUV_ORDER_UYVY
      const uint8_t u = buf[2 * i], ya = buf[2 * i + 1], v = buf[2 * i + 2], yb = buf[2 * i + 3];
#else
      const uint8_t ya = buf[2 * i], u = buf[2 * i + 1], yb = buf[2 * i + 2], v = buf[2 * i + 3];
#endif
      const int y0 = clamp8((int)ya - c);
      const int y1 = clamp8((int)yb - c);
      yPlane[i] = (uint8_t)y0;
      yPlane[i + 1] = (uint8_t)y1;
      if (filterIdx != FILTER_COLOUR) {
        out[i] = tintLut[filterIdx][y0];
        out[i + 1] = tintLut[filterIdx][y1];
      } else {
        const int du = (int)u - 128, dv = (int)v - 128;
        const int rr = (359 * dv) >> 8;
        const int gg = (88 * du + 183 * dv) >> 8;
        const int bb = (454 * du) >> 8;
        out[i]     = packRgb565(y0 + rr, y0 - gg, y0 + bb);
        out[i + 1] = packRgb565(y1 + rr, y1 - gg, y1 + bb);
      }
    }
  }
}

// Edge highlighting from the saved brightness values (the frame is already RGB565).
// smooth = Sobel-style averaging over 3 neighbours, which cuts noise from false edges.
void drawEdgesY(uint16_t *px, int w, int h, int thr, bool smooth) {
  const uint16_t e = __builtin_bswap16(EDGE_COLORS[edgeColorIdx]);
  for (int y = 1; y < h - 1; y++) {
    const uint8_t *r0 = yPlane + (size_t)(y - 1) * w;
    const uint8_t *r1 = yPlane + (size_t)y * w;
    const uint8_t *r2 = yPlane + (size_t)(y + 1) * w;
    uint16_t *row = px + (size_t)y * w;
    for (int x = 1; x < w - 1; x++) {
      int gx, gy;
      if (smooth) {
        gx = (r0[x + 1] + 2 * r1[x + 1] + r2[x + 1]) - (r0[x - 1] + 2 * r1[x - 1] + r2[x - 1]);
        gy = (r2[x - 1] + 2 * r2[x] + r2[x + 1]) - (r0[x - 1] + 2 * r0[x] + r0[x + 1]);
        if (gx < 0) gx = -gx;
        if (gy < 0) gy = -gy;
        gx >>= 2;
        gy >>= 2;
      } else {
        gx = r1[x + 1] - r1[x - 1];
        gy = r2[x] - r0[x];
        if (gx < 0) gx = -gx;
        if (gy < 0) gy = -gy;
      }
      if (gx + gy > thr) {
        row[x] = e;
#if EDGE_THICK
        row[x + 1] = e;
        row[w + x] = e;
        row[w + x + 1] = e;
#endif
      }
    }
  }
}
#endif

#if CAPTURE_YUV
// ---------- motion detection and tracking (uses the brightness plane yPlane) ----------
static int16_t  bgq[GW_MAX * GH_MAX];        // background brightness x16, one value per block
static uint8_t  prevMov[GW_MAX * GH_MAX];    // block had changed in the previous frame too
static uint8_t  flagGrid[GW_MAX * GH_MAX];   // 1 = confirmed change, 2 = already grouped
static uint8_t  curBlk[GW_MAX * GH_MAX];     // this frame's block brightness
static uint16_t blkStack[GW_MAX * GH_MAX];
static int motionGW = 0, motionGH = 0;

void motionUpdate(int w, int h) {
  const int gw = w / MB, gh = h / MB;
  if (gw > GW_MAX || gh > GH_MAX || gw < 1 || gh < 1) return;
  const int n = gw * gh;

  // 1. average brightness of every 4x4 block
  for (int gy = 0; gy < gh; gy++)
    for (int gx = 0; gx < gw; gx++) {
      const uint8_t *p = yPlane + (size_t)(gy * MB) * w + gx * MB;
      int s = 0;
      for (int dy = 0; dy < MB; dy++) { const uint8_t *q = p + (size_t)dy * w; s += q[0] + q[1] + q[2] + q[3]; }
      curBlk[gy * gw + gx] = (uint8_t)(s >> 4);
    }

  // 2. (re)start: learn the background from this frame and wait a moment for exposure to settle
  if (motionReset || gw != motionGW || gh != motionGH) {
    for (int i = 0; i < n; i++) { bgq[i] = (int16_t)(curBlk[i] << 4); prevMov[i] = 0; }
    motionGW = gw; motionGH = gh;
    motionReset = false;
    motionWarm = 12;
    for (int k = 0; k < MAXTRK; k++) tracks[k].used = false;
    confirmedTracks = 0;
    return;
  }

  // 3. overall brightness drift (lighting or exposure changes) is measured and ignored
  int sum = 0, cnt = 0;
  for (int i = 0; i < n; i++) {
    const int d = curBlk[i] - ((bgq[i] + 8) >> 4);
    if (d > -20 && d < 20) { sum += d; cnt++; }
  }
  const int drift = cnt ? ((sum >= 0) ? (sum + cnt / 2) / cnt : -((-sum + cnt / 2) / cnt)) : 0;

  // 4. mark blocks that changed in two frames in a row, and update the background
  const int thr = MOTION_THR[motionSens];
  int movCount = 0;
  for (int i = 0; i < n; i++) {
    int d = curBlk[i] - ((bgq[i] + 8) >> 4) - drift;
    if (d < 0) d = -d;
    const bool mov = d > thr;
    flagGrid[i] = (mov && prevMov[i]) ? 1 : 0;
    prevMov[i] = mov ? 1 : 0;
    if (mov) movCount++;
    const int shift = mov ? 8 : 5;                          // changing blocks barely update
    bgq[i] = (int16_t)(bgq[i] + ((((int)curBlk[i] << 4) - bgq[i] + (1 << (shift - 1))) >> shift));
  }
  if (movCount * 2 > n) { motionReset = true; return; }     // most of the picture changed: camera moved or lights changed
  if (motionWarm > 0) { motionWarm--; return; }

  // 5. group changed blocks into objects (8-neighbour flood fill)
  MotionDet det[MAXDET];
  int nDet = 0;
  const int minBlk = MOTION_MINBLK[motionSens];
  for (int s0 = 0; s0 < n; s0++) {
    if (flagGrid[s0] != 1) continue;
    int sp = 0;
    blkStack[sp++] = (uint16_t)s0;
    flagGrid[s0] = 2;
    int x0 = gw, y0 = gh, x1 = -1, y1 = -1, c = 0, sx = 0, sy = 0;
    while (sp > 0) {
      const int idx = blkStack[--sp];
      const int gx = idx % gw, gy = idx / gw;
      c++; sx += gx; sy += gy;
      if (gx < x0) x0 = gx;
      if (gx > x1) x1 = gx;
      if (gy < y0) y0 = gy;
      if (gy > y1) y1 = gy;
      for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++) {
          if (!dx && !dy) continue;
          const int nx = gx + dx, ny = gy + dy;
          if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue;
          const int ni = ny * gw + nx;
          if (flagGrid[ni] == 1) { flagGrid[ni] = 2; blkStack[sp++] = (uint16_t)ni; }
        }
    }
    if (c < minBlk) continue;
    MotionDet d = {(int16_t)x0, (int16_t)y0, (int16_t)x1, (int16_t)y1, (int16_t)(sx / c), (int16_t)(sy / c), (int16_t)c};
    if (nDet < MAXDET) det[nDet++] = d;
    else {                                                  // keep the largest objects
      int smallest = 0;
      for (int k = 1; k < MAXDET; k++) if (det[k].n < det[smallest].n) smallest = k;
      if (d.n > det[smallest].n) det[smallest] = d;
    }
  }

  // 6. follow objects from frame to frame (nearest match within 14 blocks)
  bool used[MAXDET];
  for (int k = 0; k < MAXDET; k++) used[k] = false;
  for (int k = 0; k < MAXTRK; k++) {
    MotionTrack &tr = tracks[k];
    if (!tr.used) continue;
    int best = -1, bestD = 14 * 14;
    for (int di = 0; di < nDet; di++) {
      if (used[di]) continue;
      const int dx = det[di].cx - tr.cx, dy = det[di].cy - tr.cy;
      const int d2 = dx * dx + dy * dy;
      if (d2 < bestD) { bestD = d2; best = di; }
    }
    if (best >= 0) {
      const MotionDet &d = det[best];
      used[best] = true;
      tr.x0 = d.x0; tr.y0 = d.y0; tr.x1 = d.x1; tr.y1 = d.y1; tr.cx = d.cx; tr.cy = d.cy;
      // "still" counts frames since the object last got more than 2 blocks away from its anchor
      // point, so slow movement still counts as movement
      int adx = tr.cx - tr.ax, ady = tr.cy - tr.ay;
      if (adx < 0) adx = -adx;
      if (ady < 0) ady = -ady;
      if (adx > 2 || ady > 2) { tr.moved = true; tr.still = 0; tr.ax = tr.cx; tr.ay = tr.cy; }
      else if (tr.still < 255) tr.still++;
      if (tr.age < 255) tr.age++;
      tr.miss = 0;
      for (int j = TRAIL_LEN - 1; j > 0; j--) { tr.tx[j] = tr.tx[j - 1]; tr.ty[j] = tr.ty[j - 1]; }
      tr.tx[0] = tr.cx; tr.ty[0] = tr.cy;
      if (tr.tn < TRAIL_LEN) tr.tn++;
    } else if (++tr.miss > 6) {
      tr.used = false;
    }
  }
  for (int di = 0; di < nDet; di++) {
    if (used[di]) continue;
    for (int k = 0; k < MAXTRK; k++) {
      if (tracks[k].used) continue;
      MotionTrack &tr = tracks[k];
      const MotionDet &d = det[di];
      tr.used = true; tr.age = 1; tr.miss = 0; tr.tn = 1; tr.still = 0; tr.moved = false;
      tr.x0 = d.x0; tr.y0 = d.y0; tr.x1 = d.x1; tr.y1 = d.y1; tr.cx = d.cx; tr.cy = d.cy; tr.ax = d.cx; tr.ay = d.cy;
      tr.tx[0] = d.cx; tr.ty[0] = d.cy;
      break;
    }
  }

  // 7. objects that have stopped moving are absorbed into the background and dropped
  for (int k = 0; k < MAXTRK; k++) {
    MotionTrack &tr = tracks[k];
    if (!tr.used) continue;
    if ((!tr.moved && tr.still >= STILL_NEW_LIMIT) || (tr.moved && tr.still >= STILL_MOVED_LIMIT)) {
      for (int gy = tr.y0; gy <= tr.y1; gy++)
        for (int gx = tr.x0; gx <= tr.x1; gx++) {
          const int i = gy * gw + gx;
          bgq[i] = (int16_t)(curBlk[i] << 4);
          prevMov[i] = 0;
        }
      tr.used = false;
    }
  }

  // 8. an object counts once it has been seen in 3 frames; tall, narrow ones are marked "person-like"
  confirmedTracks = 0;
  for (int k = 0; k < MAXTRK; k++) {
    MotionTrack &tr = tracks[k];
    if (!tr.used) continue;
    const int bw = tr.x1 - tr.x0 + 1, bh = tr.y1 - tr.y0 + 1;
    tr.tall = (bh >= 6) && (bh * 10 >= bw * 14);
    if (tr.age >= 3) confirmedTracks++;
  }
}
#endif

// Turn the WS2812 status LED off (needs LED_GPIO set above)
void ledsOff() {
  if (LED_GPIO >= 0) {
    neopixelWrite(LED_GPIO, 0, 0, 0);
    delay(2);
    neopixelWrite(LED_GPIO, 0, 0, 0);
  }
}

// =====================================================================
void setup() {
  Serial.begin(115200);
  pinMode(BTN_PIN, INPUT_PULLUP);

  lcdInit();
  ledsOff();
  backlightInit();
  backlightSet(BL_LEVELS[blIndex]);
  lcdFill(0x0000);

  if (!psramFound()) {
    Serial.println("PSRAM not found - set Tools > PSRAM > OPI PSRAM");
    lcdFill(0xF800);                 // red screen
    while (true) delay(1000);
  }

#if CAPTURE_YUV
  initTintLuts();
#endif
  camera_config_t &cfg = camCfg;   // global copy, so the camera can be restarted
  cfg.ledc_channel = LEDC_CHANNEL_7;   // camera clock gets its own LEDC timer/channel
  cfg.ledc_timer   = LEDC_TIMER_3;     // so it can't collide with the backlight PWM
  cfg.pin_d0 = Y2_GPIO_NUM;  cfg.pin_d1 = Y3_GPIO_NUM;
  cfg.pin_d2 = Y4_GPIO_NUM;  cfg.pin_d3 = Y5_GPIO_NUM;
  cfg.pin_d4 = Y6_GPIO_NUM;  cfg.pin_d5 = Y7_GPIO_NUM;
  cfg.pin_d6 = Y8_GPIO_NUM;  cfg.pin_d7 = Y9_GPIO_NUM;
  cfg.pin_xclk  = XCLK_GPIO_NUM;
  cfg.pin_pclk  = PCLK_GPIO_NUM;
  cfg.pin_vsync = VSYNC_GPIO_NUM;
  cfg.pin_href  = HREF_GPIO_NUM;
  cfg.pin_sccb_sda = SIOD_GPIO_NUM;
  cfg.pin_sccb_scl = SIOC_GPIO_NUM;
  cfg.pin_pwdn  = PWDN_GPIO_NUM;
  cfg.pin_reset = RESET_GPIO_NUM;
  cfg.xclk_freq_hz = 20000000;
  cfg.pixel_format = CAPTURE_YUV ? PIXFORMAT_YUV422 : PIXFORMAT_RGB565;
  cfg.frame_size   = CAM_FRAMESIZE;
  cfg.fb_count     = USE_PIPELINE ? 3 : 2;   // pipeline needs a third buffer
  cfg.fb_location  = CAMERA_FB_IN_PSRAM;
  cfg.grab_mode    = CAMERA_GRAB_LATEST;

  esp_err_t err = esp_camera_init(&cfg);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed: 0x%x\n", err);
    lcdFill(0xF81F);                 // magenta screen
    while (true) delay(1000);
  }
  {
    sensor_t *s0 = esp_camera_sensor_get();
    if (s0) sensorPid = s0->id.PID;
    Serial.printf("Camera sensor ID 0x%04x\n", sensorPid);
    bootShowUntil = millis() + 6000;
  }
  startAutofocus();
  applyLevel();
  ledsOff();                         // again, in case camera setup disturbed the pin

#if USE_PIPELINE
  qFrames = xQueueCreate(1, sizeof(camera_fb_t *));
  xTaskCreatePinnedToCore(displayTask, "display", 6144, NULL, 2, NULL, 0);   // core 0
#endif
}

// Returns 0 = nothing, 1 = short press, 2 = medium hold, 3 = long hold
// (reported when the button is released)
int readButton() {
  static bool down = false;
  static uint32_t tDown = 0;
  bool pressed = (digitalRead(BTN_PIN) == LOW);
  if (pressed && !down) { down = true; tDown = millis(); }
  if (!pressed && down) {
    down = false;
    uint32_t held = millis() - tDown;
    if (held > 2000) return 3;
    if (held > 800)  return 2;
    if (held > 30)   return 1;
  }
  return 0;
}

// One hex digit of the sensor ID (0-9, B, E, F have letters; others show a block)
static void ovHexDigit(int x, int y, int nib, uint16_t c) {
  if (nib <= 9)       ovGlyph(x, y, nib, c);
  else if (nib == 11) ovGlyph(x, y, 13, c);   // B
  else if (nib == 14) ovGlyph(x, y, 10, c);   // E
  else if (nib == 15) ovGlyph(x, y, 12, c);   // F
  else                ovRect(x, y, 6, 10, c);
}

// Boxes and trails for objects found by the motion detector (red box = tall and narrow,
// "person-like"; yellow = anything else; a dimmer box means it was lost a moment ago)
static void drawTracks() {
  for (int k = 0; k < MAXTRK; k++) {
    const MotionTrack &tr = tracks[k];
    if (!tr.used || tr.age < 3) continue;
    const uint16_t col = tr.tall ? (tr.miss ? 0x8000 : 0xF800) : (tr.miss ? 0x8400 : 0xFFE0);
    const int px0 = tr.x0 * MB, py0 = tr.y0 * MB;
    const int bw = (tr.x1 - tr.x0 + 1) * MB, bh = (tr.y1 - tr.y0 + 1) * MB;
    ovRect(px0, py0, bw, 1, col);
    ovRect(px0, py0 + bh - 1, bw, 1, col);
    ovRect(px0, py0, 1, bh, col);
    ovRect(px0 + bw - 1, py0, 1, bh, col);
    for (int j = 0; j < tr.tn; j++)                                // trail
      ovRect(tr.tx[j] * MB + MB / 2 - 1, tr.ty[j] * MB + MB / 2 - 1, 2, 2, 0x07FF);
  }
}

// Small square showing a filter: its tint colour, or red/green/blue stripes for colour
static void ovFilterSwatch(int x, int y, int w, int h, int idx) {
  if (idx == FILTER_COLOUR) {
    const int s = w / 3;
    ovRect(x, y, s, h, 0xF800);
    ovRect(x + s, y, s, h, 0x07E0);
    ovRect(x + 2 * s, y, w - 2 * s, h, 0x001F);
  } else {
    ovRect(x, y, w, h, rgb565(TINT[idx][0], TINT[idx][1], TINT[idx][2]));
  }
}

// Menu panel: row F = filter, row E = edge colour. A yellow block marks the selected row.
static void drawMenu() {
  const int px = 6, py = 24, pw = 78, ph = 80;
  ovRect(px - 2, py - 2, pw + 4, ph + 4, 0xFFFF);
  ovRect(px - 1, py - 1, pw + 2, ph + 2, 0x0000);
  for (int r = 0; r < 4; r++) {
    const int ry = py + 6 + r * 18;
    if (menuItem == r) ovRect(px + 3, ry + 2, 4, 6, 0xFFE0);          // selection marker
    ovGlyph(px + 12, ry, r == 0 ? 12 : (r == 1 ? 10 : (r == 2 ? 14 : 5)), 0x07FF);   // F, E, M, S
    int number;
    if (r == 0) { ovFilterSwatch(px + 28, ry, 22, 10, filterIdx); number = filterIdx + 1; }
    else if (r == 1) { ovRect(px + 28, ry, 22, 10, EDGE_COLORS[edgeColorIdx]); number = edgeColorIdx + 1; }
    else if (r == 2) { ovRect(px + 28, ry, 22, 10, motionOn ? 0xF800 : 0x4208); number = motionOn ? 1 : 0; }
    else {                                                            // sensitivity: 5 small bars
      for (int i = 0; i < 5; i++) ovRect(px + 28 + i * 5, ry, 4, 10, (i <= motionSens) ? 0xFFFF : 0x4208);
      number = motionSens + 1;
    }
    ovGlyph(px + 58, ry, number, 0xFFFF);
  }
}

// Settings overlay, drawn on the image every frame
void drawOverlay(uint16_t *px, int w, int h, float fps) {
  ovBuf = px; ovW = w; ovH = h;
  if (motionOn) drawTracks();
  const int y = 4;
  int x = 4;

  ovRect(x - 1, y - 1, 12, 12, 0x0000);                        // palette square + border
  ovFilterSwatch(x, y, 10, 10, filterIdx);                     // current filter colour
  x += 16;

  if (gainLevel < NUM_LOW) {                                   // low-gain settings: L1-L4
    ovGlyph(x, y, 11, 0x07FF);
    ovGlyph(x + 8, y, gainLevel + 1, 0x07FF);
    x += 16;
  } else if (gainLevel >= NUM_LOW + NUM_NIGHT) {               // capped exposure: F1-F3, B1-B3
    int k = gainLevel - (NUM_LOW + NUM_NIGHT);
    ovGlyph(x, y, k < 3 ? 12 : 13, 0x07FF);                    // F or B
    ovGlyph(x + 8, y, (k % 3) + 1, 0x07FF);
    x += 16;
  } else {
    int lvl = gainLevel - NUM_LOW + 1;                         // night levels 1-10
    if (lvl >= 10) {
      ovGlyph(x, y, 1, 0x07FF);
      ovGlyph(x + 8, y, 0, 0x07FF);
      x += 16;
    } else {
      ovGlyph(x, y, lvl, 0x07FF);
      x += 8;
    }
  }
  if (edgesOn) { ovGlyph(x + 2, y, 10, 0xFFE0); x += 10; }     // yellow E = edges on
  x += 3;
  ovRect(x - 1, y + 3, 6, 4, 0x0000);                          // small dash between setting and fps
  ovRect(x, y + 4, 4, 2, 0x7BEF);
  x += 8;

  int f = (int)(fps + 0.5f);                                   // frames per second
  if (f > 99) f = 99;
  if (f >= 10) { ovGlyph(x, y, f / 10, 0x07E0); x += 8; }
  ovGlyph(x, y, f % 10, 0x07E0);
  if (motionOn) {                                              // M + number of objects followed
    x += 12;
    ovGlyph(x, y, 14, motionWarm > 0 ? 0x7BEF : 0xF800);      // grey while learning, red when watching
    ovGlyph(x + 8, y, confirmedTracks > 9 ? 9 : confirmedTracks, 0xFFFF);
  }

  const int xb = w - 30;                                       // backlight bars, top-right
  ovRect(xb - 1, y - 1, 28, 12, 0x0000);
  for (int i = 0; i < 4; i++)
    ovRect(xb + i * 7, y, 5, 10, (i < 4 - blIndex) ? 0xFFFF : 0x4208);

  if (millis() < bootShowUntil && sensorPid) {                 // sensor ID for the first seconds
    for (int i = 0; i < 4; i++)
      ovHexDigit(4 + i * 8, 20, (sensorPid >> (12 - 4 * i)) & 0xF, 0xFFFF);
  }
  if (menuOpen) drawMenu();
}

void loop() {
#if !USE_PIPELINE
  static uint32_t frames = 0, t0 = millis();
#endif

  int b = readButton();
  if (menuOpen) {                         // ---- menu: short = change value, medium = next row, long = close
    if (b == 1) {
      if (menuItem == 0)      { filterIdx = (filterIdx + 1) % NUM_FILTERS; applyLevel(); }
      else if (menuItem == 1) { edgeColorIdx = (edgeColorIdx + 1) % NUM_EDGE_COLORS; }
      else if (menuItem == 2) { motionOn = !motionOn; motionReset = true; }
      else                    { motionSens = (motionSens + 1) % 5; }
    }
    if (b == 2) menuItem = (menuItem + 1) % 4;
    if (b == 3) menuOpen = false;
  } else {                                // ---- normal: short = next setting, medium = backlight, long = menu
    if (b == 1) {
      gainLevel = (gainLevel + 1) % NUM_LEVELS;
      if (gainLevel == 0) {               // wrapped round to the start: toggle edges, restart camera
        edgesOn = !edgesOn;
        cameraRestart();
      }
      applyLevel();
    }
    if (b == 2) { blIndex = (blIndex + 1) % 4; backlightSet(BL_LEVELS[blIndex]); }
    if (b == 3) { menuOpen = true; menuItem = 0; }
  }

  camera_fb_t *fb = esp_camera_fb_get();
  if (!fb) return;

  if (fb->width > SCR_W || fb->height > SCR_H) {           // frame doesn't fit the screen
    esp_camera_fb_return(fb);
    return;
  }

#if CAPTURE_YUV
  const LevelDef &lv = LEVELS[gainLevel];
  const int thr = lv.edge * EDGE_SCALE / 100;
  yuvToRgb565(fb->buf, fb->width, fb->height, lv.clean);        // also saves brightness for edges
  if (edgesOn) drawEdgesY((uint16_t *)fb->buf, fb->width, fb->height, thr, lv.clean);
  if (motionOn) motionUpdate(fb->width, fb->height);            // uses the brightness plane
#else
#if SWAP_BYTES
  for (size_t i = 0; i + 1 < fb->len; i += 2) { uint8_t t = fb->buf[i]; fb->buf[i] = fb->buf[i + 1]; fb->buf[i + 1] = t; }
#endif
  {
    int thr6 = LEVELS[gainLevel].edge * EDGE_SCALE / 100 / 4;     // RGB565 green is 6-bit
    if (thr6 < 1) thr6 = 1;
    if (edgesOn) drawEdges((uint16_t *)fb->buf, fb->width, fb->height, thr6);
  }
#endif
  drawOverlay((uint16_t *)fb->buf, fb->width, fb->height, lastFps);

#if USE_PIPELINE
  sendToDisplay(fb);                       // display task sends it and returns the buffer
#else
  uint16_t x0 = (SCR_W - fb->width) / 2;
  uint16_t y0 = (SCR_H - fb->height) / 2;                  // centred vertically
  lcdPush(x0, y0, fb->width, fb->height, fb->buf);
  esp_camera_fb_return(fb);

  frames++;
  if (millis() - t0 >= 1000) {
    lastFps = frames * 1000.0f / (millis() - t0);
    Serial.printf("filter %d setting %d%s  %.1f fps  backlight step %d\n",
                  filterIdx, gainLevel, edgesOn ? " +edges" : "", (float)lastFps, blIndex);
    frames = 0;
    t0 = millis();
  }
#endif
}
